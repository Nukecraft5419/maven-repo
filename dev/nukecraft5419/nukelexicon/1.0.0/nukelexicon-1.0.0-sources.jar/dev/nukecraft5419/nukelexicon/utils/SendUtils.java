/*
 * MIT License
 *
 * Copyright (c) 2026 Nukecraft5419
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package dev.nukecraft5419.nukelexicon.utils;

import dev.nukecraft5419.nukelexicon.NukeLexicon;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Utility class for delivering formatted messages to players and console.
 * Utilizes Adventure's BukkitAudiences to safely send modern Components on Spigot servers.
 */
public class SendUtils {

    private SendUtils() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    // =========================================
    // FULL METHODS (With TagResolver parameter)
    // =========================================

    /**
     * Formats and sends a single MiniMessage string to a CommandSender.
     *
     * @param sender    The recipient (Player or Console).
     * @param message   The raw string containing MiniMessage tags.
     * @param extraTags Optional custom Placeholder tags to resolve (use TagResolver.empty() if none).
     */
    public static void sendMessage(CommandSender sender, String message, TagResolver extraTags) {
        if (sender == null || message == null || message.isEmpty()) return;

        // 1. Convert the raw string into an Adventure Component using our format engine
        Component component = MessagesUtils.format(sender, message, extraTags);

        // 2. Deliver the Component using the Adventure Platform bridge.
        // This is necessary because native Spigot CommandSenders do not support Component objects directly.
        NukeLexicon.getInstance().getAdventure().sender(sender).sendMessage(component);
    }

    /**
     * Formats and sends a list of MiniMessage strings to a CommandSender.
     *
     * @param sender    The recipient (Player or Console).
     * @param messages  The list of raw strings to send.
     * @param extraTags Optional custom Placeholder tags to resolve (use TagResolver.empty() if none).
     */
    public static void sendMessages(CommandSender sender, List<String> messages, TagResolver extraTags) {
        if (sender == null || messages == null || messages.isEmpty()) return;

        for (String msg : messages) {
            sendMessage(sender, msg, extraTags);
        }
    }

    /**
     * Translates and sends a single message to a CommandSender based on their client language.
     * Automatically retrieves the string from the locales folder and applies formatting.
     *
     * @param sender    The recipient of the message (Player or Console).
     * @param path      The YAML key path in the locale file (e.g., "messages.welcome").
     * @param extraTags Additional custom Placeholder tags to resolve (can be TagResolver.empty()).
     */
    public static void sendTranslation(CommandSender sender, String path, TagResolver extraTags) {
        if (sender == null || path == null || path.isEmpty()) return;

        String rawMessage = NukeLexicon.getInstance().getLanguageManager().getRawMessage(sender, path);

        if (rawMessage == null || rawMessage.isEmpty()) return;

        sendMessage(sender, rawMessage, extraTags);
    }

    /**
     * Translates and sends a list of messages to a CommandSender based on their client language.
     * Automatically retrieves the correct string list from the locales folder and applies
     * MiniMessage formatting and PlaceholderAPI parsing.
     *
     * @param sender    The recipient of the messages (Player or Console).
     * @param path      The YAML key path to the string list in the locales file (e.g., "plugin.help").
     * @param extraTags Optional custom Placeholder tags to resolve (use TagResolver.empty() if none).
     */
    public static void sendTranslations(CommandSender sender, String path, TagResolver extraTags) {
        // 1. Validate inputs to prevent errors
        if (sender == null || path == null || path.isEmpty()) return;

        // 2. Retrieve the raw list of strings tailored to the player's language
        List<String> rawMessages = NukeLexicon.getInstance().getLanguageManager().getRawMessageList(sender, path);

        // 3. If the list is missing or empty in the config, silently abort
        if (rawMessages == null || rawMessages.isEmpty()) return;

        // 4. Delegate to the existing list sender (which handles formatting and dispatching)
        sendMessages(sender, rawMessages, extraTags);
    }

    /**
     * Shorthand to send a formatted message directly to the server console.
     * Useful for startup, shutdown, or debugging logs.
     *
     * @param message   The message to log (supports custom tags like {@code <prefix>} and colors like {@code <green>}).
     * @param extraTags Optional custom Placeholder tags to resolve (use TagResolver.empty() if none).
     */
    public static void log(String message, TagResolver extraTags) {
        sendMessage(Bukkit.getConsoleSender(), message, extraTags);
    }

    // =========================================
    // SHORTHAND METHODS (No TagResolver needed)
    // =========================================

    /**
     * Formats and sends a single MiniMessage string to a CommandSender.
     *
     * @param sender  The recipient (Player or Console).
     * @param message The raw string containing MiniMessage tags.
     */
    public static void sendMessage(CommandSender sender, String message) {
        sendMessage(sender, message, TagResolver.empty());
    }

    /**
     * Formats and sends a list of MiniMessage strings to a CommandSender.
     *
     * @param sender   The recipient (Player or Console).
     * @param messages The list of raw strings to send.
     */
    public static void sendMessages(CommandSender sender, List<String> messages) {
        sendMessages(sender, messages, TagResolver.empty());
    }

    /**
     * Translates and sends a single message to a CommandSender based on their client language.
     *
     * @param sender The recipient of the message (Player or Console).
     * @param path   The YAML key path in the locale file.
     */
    public static void sendTranslation(CommandSender sender, String path) {
        sendTranslation(sender, path, TagResolver.empty());
    }

    /**
     * Translates and sends a list of messages to a CommandSender based on their client language.
     *
     * @param sender The recipient of the messages (Player or Console).
     * @param path   The YAML key path to the string list in the locales file.
     */
    public static void sendTranslations(CommandSender sender, String path) {
        sendTranslations(sender, path, TagResolver.empty());
    }

    /**
     * Logs a formatted message directly to the server console.
     *
     * @param message The message to log.
     */
    public static void log(String message) {
        log(message, TagResolver.empty());
    }
}
